from src import add

def test_answer():
    assert add.add(1, 1) == 2
