"""
add.py
====================================
Adding numbers
"""


def add(x, y):
    """
    Add two numbers together.

    Parameters
    ----------
    x
            A number.

    y
            A number.
    """

    return x + y
