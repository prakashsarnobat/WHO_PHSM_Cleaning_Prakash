
def add(x, y):
    '''Add two numbers together.'''
    
    return(x + y)
